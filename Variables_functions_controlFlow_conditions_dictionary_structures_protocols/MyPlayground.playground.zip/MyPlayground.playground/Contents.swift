import Foundation
print("abc")

print("Sum of 5+4 =  \(5+4).")  //using value in between string

//Variables
var b = 15
let c = 19

b = 13
//c = 20 not possible

print("b: \(b)")
print("c: \(c)")

//Pra
var d = 5
var e = 8

var f = d
d = e
e = f

print("d: \(d)")
print("e: \(e)")


//Array
var a = [1,2,3,4]
var g = ["dev","cav"]
//write code such that output is (1*2=2,6,12)

for i in 0...2{
    print(a[i]*a[i+1])
}

var k = Int.random(in: 2...10)
var kk = Int.random(in: 2..<10) //between 2 and 10 excluding 10.
var kkk = Float.random(in: 2..<10)
var kkkk = Bool.random()
var ar = [1,2,3,4,5]
ar.shuffle()
print(ar)
print(k)
print(kk)
print(kkk)
print(kkkk)


//Functions
func buyMilk()
{
    print("Ooooo Its me dude.")
    func m2(){
        print(10)
    }
    
    m2()
}

buyMilk()


func ok(n: Int)
{
    print(n)
}

var _n:Int = 10
ok(n: _n)

func okk(n1: String)
{
    print(n1)
}

var _n1:String = "dev"
okk(n1: _n1)
okk(n1: "mann")



//Flow controls

//if-else

let aa = Int.random(in: 1...900)
if(aa == 90)
{
    print("ok")
}
else if(aa < 90)
{
    print("good")
}
else{
    print("bye")
}

//switch
let no = "soft"
switch(no){
case "soft":
    print(5)
case "medium":
    print(6)
case "hard":
    print(8)
default:
    print("Choose")
}

let pk = Int.random(in: 1...100)

switch pk{
case 81...100:
    print("greater than 80")
case 61..<80:
    print("greater than 60")
case ...60:
    print("smaller")
default:
    print("samajha")
}

//dictionary

let dic = ["dev": "devyansh", "mani": "manisha"]

let d1 : [String:Int] = ["dev": 456, "mani": 2456]

print(d1["dev"]!)


//optional container

//var nam : String = nil    error as it can be nil so we need to add optional
var nam : String? = nil

nam = "dev"
print(nam) //to remove optional key word we use !
print(nam!)
print()
print()

//CountDown
var secondsRemaining = 1

Timer.scheduledTimer(withTimeInterval: 1, repeats: true){(Timer) in
    if secondsRemaining > 0 {
            print ("\(secondsRemaining) seconds")
            secondsRemaining -= 1
        } else {
            Timer.invalidate()
        }
}


//structures: helps to create out own data type

//struct MyStruct { }     call:MyStruct()

struct Town{
    let name = "Ranchi"
    var citizens = ["Jack","Dev"]
    var resources = ["Grain": 100, "Ore": 42, "Wool": 75]
    
}

var myTown = Town()
myTown.citizens.append("Devyansh")
print(myTown.resources.count)
print(myTown.citizens)
print("My town \(myTown.name) has \(myTown.resources["Grain"]!) bags of grains and \(myTown.citizens) citizens")


struct Towns{
    let name: String
    var citizens: [String]
    var resources: [String:Int]
    
    init(name: String, citizens: [String], resources: [String:Int]) {
        self.name = name
        self.citizens = citizens
        self.resources = resources
    }
    
    func okkji(){
        print("OkJii")
    }
    
}


var myTowns = Towns(name: "Ran",citizens: ["dev","cave"],resources: ["pro": 78])
myTowns.citizens.append("Kro")
print(myTowns.citizens)
myTowns.okkji()


//Function with return
let money = 100
func getIce(money: Int) -> Int {
    let mon = money - 10
    return mon
}

print(getIce(money: money))



//Structures are immutable as by default let keyword is used before struct so...

struct Townsss{
    let name: String
    var citizens: [String]
    var resources: [String:Int]
    
    init(name: String, citizens: [String], resources: [String:Int]) {
        self.name = name
        self.citizens = citizens
        self.resources = resources
    }
    
    mutating func addResource(){
        resources["myBrain"] = 100
    }
    // so to mutate we need to add word mutatings
}


var myTo = Townsss(name: "Ran", citizens: ["dev","shave"], resources: ["pro" : 90])

myTo.addResource()

print(myTo)


// Protocols

//protocol MyProtocol {
//    // define requirements
//}
//
//struct MyStruct: MyProtocol {}
//class MyClass: MyProtocol {}

import UIKit

//passing function as a parameter

func Calculator(n1: Int, n2: Int, operation: (Int , Int) -> Int) -> Int {
    return operation(n1, n2)
}

func add(no1: Int, no2: Int) -> Int {
    return no1+no2
}

func multiply(no1: Int, no2: Int) -> Int {
    return no1*no2
}


let k = Calculator(n1: 2, n2: 3, operation: add)
print(k)

let k1 = Calculator(n1: 2, n2: 3, operation: multiply)
print(k1)


//making a clouser function for division
let k2 = Calculator(n1: 4, n2: 2, operation: {(no1: Int, no2: Int) -> Int in
    return no1/no2
})

//same as above statement
let k3 = Calculator(n1: 4, n2: 2, operation: {(no1, no2) in no1/no2})

//same as above as parameter is defined as $0 and 2nd as $1
let k4 = Calculator(n1: 4, n2: 2, operation: {$0 / $1})

//same as above as if last parameter is a clouser then we can remove its name
let k5 = Calculator(n1: 4, n2: 2){$0 / $1}


//map function
// lets say we have an array and we need to add 1 in all the numbers in the array then:

let arr = [1,2,3,4,5,6]

func addOne(n1: Int) -> Int {
        return n1 + 1
}

print(arr.map(addOne))
//using clouser
print(arr.map(){$0 + 1})

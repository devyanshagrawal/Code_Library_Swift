import UIKit

//var myDouble = 3.14159
//
//let myRoundedDouble = String(format: "%.2f", myDouble)

//print(myRoundedDouble)
//myDouble.round()
//print(myDouble)


// lets say we need to round the number upto one decimal place without using string then we can use .round() function but it will round the number to integer but using the extension we can extends its functions.

extension Double {
    func round(to places: Int) -> Double {
        let precisionNumber = pow(10, Double(places))
        var n = self
        n = n * precisionNumber
        n.round()
        n = n / precisionNumber
        return n
    }
}
var myDouble = 3.14159

myDouble.round(to: 3)
